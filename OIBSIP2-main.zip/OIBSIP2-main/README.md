# OIBSIP2
Spam Message Detector
Build a spam message detector using machine learning library called scikit learn and joblib.
